# NYP107-2 > 2024-12-30 4:59pm
https://universe.roboflow.com/nyp107/nyp107-2

Provided by a Roboflow user
License: CC BY 4.0

