# NYP107 > 2024-12-29 9:48pm
https://universe.roboflow.com/nyp107/nyp107

Provided by a Roboflow user
License: CC BY 4.0

